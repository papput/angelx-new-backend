const User = require("../models/User");
const OtpSession = require("../models/OtpSession");
const { maskPhone } = require("../middleware/auth");
const catchAsyncError = require("../utils/catchAsyncError");
const sendToken = require("../utils/sendToken");
const { ErrorHandler } = require("../utils/ErrorHandler");
const { sendOtp } = require("../utils/otpVerification");
const {
  saveOTPSession,
  verifyOTPSession,
  deleteOTPSession,
  generateSecureOTP,
} = require("../utils/otpUtils");
const Admin = require("../models/Admin");

// @desc    Send phone number for OTP verification
// @access  Public
const login = catchAsyncError(async (req, res, next) => {
  const { phone } = req.body;

  const cleanPhone = phone.trim();

  // Validate phone number
  if (!cleanPhone || !/^\d{10}$/.test(cleanPhone)) {
    return next(
      new ErrorHandler("Please enter a valid 10-digit phone number.", 400)
    );
  }
  const apiKey = process.env.OTP_API_KEY;

  const otp = generateSecureOTP();
  // Send OTP via 2Factor API (let 2Factor generate the OTP)

  // Check if API key is configured
  if (!apiKey) {
    console.error("OTP_API_KEY is not configured in environment variables");
    return next(
      new ErrorHandler(
        "OTP service is not properly configured. Please contact administrator.",
        500
      )
    );
  }

  try {
    const result = await sendOtp(apiKey, cleanPhone, otp);
    console.log(" API Response:", result); // Log for debugging

    if (result.data.status == 1) {
      await saveOTPSession(cleanPhone, otp);

      res.status(200).json({
        success: true,
        message: "OTP sent successfully",
        data: {
          phone: cleanPhone,
          maskedPhone: maskPhone(cleanPhone),
        },
      });
    } else {
      console.error(" API Error:");
      return next(new ErrorHandler("Failed to send OTP:", 500));
    }
  } catch (error) {
    console.error("Failed to send OTP:", error);
    return next(new ErrorHandler("Failed to send OTP: " + error.message, 500));
  }
});

// @desc    Verify OTP and login/register user
// @access  Public
const verifyOtpController = catchAsyncError(async (req, res, next) => {
  const { phone, otp } = req.body;

  const cleanPhone = phone.trim();

  // Validate inputs
  if (!cleanPhone || !/^\d{10}$/.test(cleanPhone)) {
    return next(
      new ErrorHandler("Please enter a valid 10-digit phone number.", 400)
    );
  }

  if (!otp || otp.length !== 6 || !/^\d{6}$/.test(otp)) {
    return next(new ErrorHandler("Please enter a valid 6-digit OTP.", 400));
  }

  // Verify OTP session from database
  const sessionVerification = await verifyOTPSession(cleanPhone);
  if (!sessionVerification.valid) {
    return next(new ErrorHandler(sessionVerification.message, 400));
  }

  // Check if OTP matches (only if stored in database)
  if (
    sessionVerification.session.otp &&
    sessionVerification.session.otp !== otp
  ) {
    return next(new ErrorHandler("Invalid OTP. Please try again.", 400));
  }

  try {
    // Clean up session data
    await deleteOTPSession(cleanPhone);

    let user = await User.findOne({ phone: cleanPhone });

    if (!user) {
      // Create new user if doesn't exist
      user = new User({
        phone: cleanPhone,
        totalBalance: 0,
        availableBalance: 0,
        limitBalance: 0,
      });

      await user.save();
    }

    // Send token using sendToken utility
    sendToken(user, 200, res);
  } catch (error) {
    console.error("Failed to verify OTP:", error);
    // Clean up session data even on error
    await deleteOTPSession(cleanPhone);
    return next(
      new ErrorHandler("Failed to verify OTP: " + error.message, 500)
    );
  }
});

// @desc    Logout user
// @access  Private
const logout = catchAsyncError(async (req, res, next) => {
  res.cookie("token", null, {
    expires: new Date(Date.now()),
    httpOnly: true,
  });

  res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
});

// @desc    Send OTP for resetting transaction password
// @access  Private
const sendTransactionPasswordResetOtp = catchAsyncError(
  async (req, res, next) => {
    const user = await User.findById(req.user._id);

    if (!user) {
      return next(new ErrorHandler("User not found", 404));
    }

    const cleanPhone = user.phone.trim();
    const apiKey = process.env.OTP_API_KEY;
    const otp = generateSecureOTP();

    if (!apiKey) {
      return next(new ErrorHandler("OTP service is not configured", 500));
    }

    try {
      const result = await sendOtp(apiKey, cleanPhone, otp);
      console.log("Transaction Password Reset OTP Response:", result.data);

      if (result.data.status == 1) {
        await saveOTPSession(cleanPhone, otp);

        return res.status(200).json({
          success: true,
          message: "OTP sent successfully to your registered number",
          data: {
            phone: cleanPhone,
            maskedPhone: maskPhone(cleanPhone),
          },
        });
      } else {
        return next(
          new ErrorHandler("Failed to send OTP. Please try again.", 500)
        );
      }
    } catch (error) {
      console.error("OTP sending failed:", error);
      return next(
        new ErrorHandler("Failed to send OTP: " + error.message, 500)
      );
    }
  }
);

// @desc    Verify OTP and reset transaction password
// @access  Private
const verifyTransactionPasswordResetOtp = catchAsyncError(
  async (req, res, next) => {
    const { otp, transactionPassword } = req.body;

    if (!otp || otp.length !== 6 || !/^\d{6}$/.test(otp)) {
      return next(new ErrorHandler("Please enter a valid 6-digit OTP.", 400));
    }

    if (
      !transactionPassword ||
      transactionPassword.length !== 6 ||
      !/^\d{6}$/.test(transactionPassword)
    ) {
      return next(
        new ErrorHandler("Transaction password must be 6 digits.", 400)
      );
    }

    const user = await User.findById(req.user._id);

    if (!user) {
      return next(new ErrorHandler("User not found", 404));
    }

    const cleanPhone = user.phone.trim();

    // ✅ Verify OTP Session
    const sessionVerification = await verifyOTPSession(cleanPhone);
    if (!sessionVerification.valid) {
      return next(new ErrorHandler(sessionVerification.message, 400));
    }

    // ✅ Check OTP Match
    if (sessionVerification.session.otp !== otp) {
      return next(new ErrorHandler("Invalid OTP. Please try again.", 400));
    }

    // ✅ All good — reset transaction password
    user.transactionPassword = transactionPassword;
    await user.save();

    // ✅ Clean OTP session
    await deleteOTPSession(cleanPhone);

    res.status(200).json({
      success: true,
      message: "Transaction password updated successfully",
    });
  }
);

// @desc    Update transaction password
// @access  Private
const updateTransactionPassword = catchAsyncError(async (req, res, next) => {
  const { transactionPassword } = req.body;

  // Validate transaction password
  if (
    !transactionPassword ||
    transactionPassword.length !== 6 ||
    !/^\d{6}$/.test(transactionPassword)
  ) {
    return next(
      new ErrorHandler("Transaction password must be exactly 6 digits", 400)
    );
  }

  // Update user's transaction password
  const user = await User.findById(req.user._id);

  if (!user) {
    return next(new ErrorHandler("User not found", 404));
  }

  user.transactionPassword = transactionPassword;
  await user.save();

  res.status(200).json({
    success: true,
    message: "Transaction password updated successfully",
  });
});

const getWhatsAppNumber = catchAsyncError(async (req, res, next) => {
  try {
    // Since there's only one admin, we can fetch the first admin record
    // Select only the whatsappNumber field
    const admin = await Admin.findOne({}).select("whatsappNumber");

    if (!admin) {
      return res.status(404).json({
        success: false,
        message: "Admin not found",
      });
    }

    res.status(200).json({
      success: true,
      whatsappNumber: admin.whatsappNumber,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = {
  login,
  verifyOtp: verifyOtpController,
  logout,
  updateTransactionPassword,
  verifyTransactionPasswordResetOtp,
  sendTransactionPasswordResetOtp,
  getWhatsAppNumber,
};
